import React, { useState, useEffect, useContext, createContext } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    TextInput,
    Switch,
    Alert,
    SafeAreaView,
    StatusBar as RNStatusBar
} from 'react-native';
import { NavigationContainer, DefaultTheme, DarkTheme, useNavigation } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons, Feather } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
// --- CONFIGURATION & CONSTANTS ---
const LightColors = {
    primaryStart: '#D946EF',
    primaryEnd: '#db2777',
    background: '#F9FAFB',
    card: '#FFFFFF',
    text: '#1F2937',     // Dark text for light mode
    textSub: '#6B7280',  // Gray text
    border: '#E5E7EB',
    inputBg: '#E5E7EB',
    iconBg: '#F3F4F6',
    white: '#FFFFFF',
    dangerBg: '#FEE2E2',
    dangerText: '#EF4444',
    success: '#10B981',
};
const DarkColors = {
    primaryStart: '#D946EF', // Keep brand colors same
    primaryEnd: '#db2777',
    background: '#111827',   // Dark Gray/Black
    card: '#1F2937',         // Darker Gray for cards
    text: '#F9FAFB',         // White text for dark mode
    textSub: '#9CA3AF',      // Light gray text
    border: '#374151',
    inputBg: '#374151',
    iconBg: '#374151',
    white: '#FFFFFF',        // Keep white for text on primary buttons
    dangerBg: '#7F1D1D',
    dangerText: '#FCA5A5',
    success: '#34D399',
};
const CHART_DAYS = ['Fri', 'Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu'];
// --- CONTEXT ---
const CounterContext = createContext();
const CounterProvider = ({ children }) => {
    const [counters, setCounters] = useState([]);
    const [history, setHistory] = useState([]);
    const [settings, setSettings] = useState({
        darkMode: false,
        notifications: false,
    });
    // Derived Theme
    const theme = settings.darkMode ? DarkColors : LightColors;
    const isDark = settings.darkMode;
    useEffect(() => {
        loadData();
    }, []);
    useEffect(() => {
        saveData();
    }, [counters, history, settings]);
    const loadData = async () => {
        try {
            const storedCounters = await AsyncStorage.getItem('@clicktally_counters');
            const storedHistory = await AsyncStorage.getItem('@clicktally_history');
            const storedSettings = await AsyncStorage.getItem('@clicktally_settings');
            if (storedCounters) setCounters(JSON.parse(storedCounters));
            if (storedHistory) setHistory(JSON.parse(storedHistory));
            if (storedSettings) setSettings(JSON.parse(storedSettings));
            if (!storedCounters) {
                setCounters([
                    { id: '1', title: 'My Counter', count: 15, color: LightColors.primaryStart, limit: 1000 }
                ]);
            }
        } catch (e) {
            console.error("Failed to load data", e);
        }
    };
    const saveData = async () => {
        try {
            await AsyncStorage.setItem('@clicktally_counters', JSON.stringify(counters));
            await AsyncStorage.setItem('@clicktally_history', JSON.stringify(history));
            await AsyncStorage.setItem('@clicktally_settings', JSON.stringify(settings));
        } catch (e) {
            console.error("Failed to save data", e);
        }
    };
    const addCounter = (title, color) => {
        const newCounter = {
            id: Date.now().toString(),
            title: title || 'New Counter',
            count: 0,
            color: color || theme.primaryStart,
            limit: 10000
        };
        setCounters([...counters, newCounter]);
    };
    const incrementCounter = (id, amount = 1) => {
        const today = new Date().toISOString().split('T')[0];
        setCounters(prev => prev.map(c => {
            if (c.id === id) return { ...c, count: c.count + amount };
            return c;
        }));
        setHistory(prev => [...prev, { date: today, count: amount, counterId: id }]);
    };
    const resetCounter = (id) => {
        setCounters(prev => prev.map(c => {
            if (c.id === id) return { ...c, count: 0 };
            return c;
        }));
    };
    const deleteCounter = (id) => {
        setCounters(prev => prev.filter(c => c.id !== id));
    };
    const clearAllData = async () => {
        setCounters([]);
        setHistory([]);
        await AsyncStorage.clear();
    };
    return (
        <CounterContext.Provider value={{
            counters, history, settings, setSettings,
            theme, isDark,
            addCounter, incrementCounter, resetCounter, deleteCounter, clearAllData
        }}>
            {children}
        </CounterContext.Provider>
    );
};
// --- COMPONENTS ---
const GradientView = ({ style, children, colors, start, end, theme }) => {
    return (
        <LinearGradient
            colors={colors || [theme.primaryStart, theme.primaryEnd]}
            start={start || { x: 0, y: 0 }}
            end={end || { x: 1, y: 0 }}
            style={style}
        >
            {children}
        </LinearGradient>
    );
};
// --- SCREENS ---
// 1. HOME SCREEN
const HomeScreen = () => {
    const { counters, theme } = useContext(CounterContext);
    const navigation = useNavigation();
    const totalCounts = counters.reduce((acc, curr) => acc + curr.count, 0);
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
            <ScrollView contentContainerStyle={styles.scrollContent}>
                {/* Header */}
                <View style={styles.header}>
                    <View style={styles.iconBg}>
                        <MaterialCommunityIcons name="star-four-points" size={24} color={theme.white} />
                    </View>
                    <View>
                        <Text style={[styles.headerTitle, { color: theme.text }]}>Click Tally</Text>
                        <Text style={[styles.headerSubtitle, { color: theme.textSub }]}>Track your counts with ease</Text>
                    </View>
                </View>
                {/* Dashboard Card */}
                <GradientView theme={theme} style={styles.dashboardCard}>
                    <Text style={styles.dashboardLabel}>Total Counts</Text>
                    <Text style={styles.dashboardValue}>{totalCounts}</Text>
                    <Text style={styles.dashboardFooter}>{counters.length} active counters</Text>
                </GradientView>
                {/* Section Header */}
                <View style={styles.sectionHeader}>
                    <Text style={[styles.sectionTitle, { color: theme.text }]}>Your Counters</Text>
                    <Text style={[styles.sectionSubtitle, { color: theme.textSub }]}>{counters.length} total</Text>
                </View>
                {/* List */}
                {counters.map((item) => (
                    <TouchableOpacity
                        key={item.id}
                        style={[styles.counterCard, { backgroundColor: theme.card, shadowColor: theme.text }]}
                        onPress={() => navigation.navigate('CounterDetail', { counterId: item.id })}
                    >
                        <LinearGradient
                            colors={[item.color, item.color]}
                            style={styles.counterIcon}
                        >
                            <Text style={styles.counterIconText}>{item.count}</Text>
                        </LinearGradient>
                        <Text style={[styles.counterTitle, { color: theme.text }]}>{item.title}</Text>
                        <Feather name="chevron-right" size={20} color={theme.textSub} />
                    </TouchableOpacity>
                ))}
            </ScrollView>
        </SafeAreaView>
    );
};
// 2. STATISTICS SCREEN
const StatsScreen = () => {
    const { counters, history, theme } = useContext(CounterContext);
    const totalCounts = counters.reduce((acc, c) => acc + c.count, 0);
    const totalActive = counters.length;
    const avgDaily = history.length > 0 ? Math.round(history.length / 7) : 0;
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
            <ScrollView contentContainerStyle={styles.scrollContent}>
                <View style={styles.header}>
                    <View>
                        <Text style={[styles.headerTitle, { color: theme.text }]}>Statistics</Text>
                        <Text style={[styles.headerSubtitle, { color: theme.textSub }]}>Your counting insights</Text>
                    </View>
                </View>
                {/* Grid */}
                <View style={styles.statsGrid}>
                    <StatsBox label="Total Counts" value={totalCounts} icon="activity" color="#8B5CF6" bg={theme.isDark ? '#2E1065' : '#EDDDFF'} theme={theme} />
                    <StatsBox label="Counters" value={totalActive} icon="target" color="#EC4899" bg={theme.isDark ? '#831843' : '#FFE4E6'} theme={theme} />
                    <StatsBox label="Avg. Daily" value={2} icon="calendar" color="#14B8A6" bg={theme.isDark ? '#064E3B' : '#DCFCE7'} theme={theme} />
                    <StatsBox label="Streak" value={7} icon="trending-up" color="#10B981" bg={theme.isDark ? '#065F46' : '#D1FAE5'} theme={theme} />
                </View>
                {/* Chart */}
                <View style={[styles.chartCard, { backgroundColor: theme.card }]}>
                    <Text style={[styles.chartTitle, { color: theme.text }]}>Last 7 Days</Text>
                    <View style={styles.chartContainer}>
                        {CHART_DAYS.map((day, index) => {
                            const heightPercentage = index === 6 ? '70%' : index === 5 ? '30%' : index === 3 ? '50%' : '10%';
                            const isToday = index === 6;
                            return (
                                <View key={day} style={styles.barContainer}>
                                    <View style={[styles.barTrack, { backgroundColor: theme.inputBg }]}>
                                        <LinearGradient
                                            colors={isToday ? [theme.primaryStart, theme.primaryEnd] : ['transparent', 'transparent']}
                                            style={[styles.barFill, { height: heightPercentage }]}
                                        />
                                    </View>
                                    <Text style={[styles.barLabel, { color: theme.textSub }]}>{day}</Text>
                                </View>
                            )
                        })}
                    </View>
                </View>
                <View style={styles.sectionHeader}>
                    <Text style={[styles.sectionTitle, { color: theme.text }]}>Top Counter</Text>
                </View>
                {counters.length > 0 && (
                    <View style={[styles.counterCard, { backgroundColor: theme.card }]}>
                        <LinearGradient
                            colors={[theme.primaryStart, theme.primaryEnd]}
                            style={styles.counterIcon}
                        >
                            <Text style={styles.counterIconText}>{counters[0].count}</Text>
                        </LinearGradient>
                        <View>
                            <Text style={[styles.counterTitle, { color: theme.text }]}>{counters[0].title}</Text>
                            <Text style={[styles.counterSubtitle, { color: theme.textSub }]}>Most active counter</Text>
                        </View>
                    </View>
                )}
            </ScrollView>
        </SafeAreaView>
    );
};
const StatsBox = ({ label, value, icon, color, bg, theme }) => (
    <View style={[styles.statBox, { backgroundColor: theme.card }]}>
        <View style={[styles.statIcon, { backgroundColor: bg }]}>
            <Feather name={icon} size={20} color={color} />
        </View>
        <Text style={[styles.statValue, { color: theme.text }]}>{value}</Text>
        <Text style={[styles.statLabel, { color: theme.textSub }]}>{label}</Text>
    </View>
);
// 3. SETTINGS SCREEN
const SettingsScreen = () => {
    const { clearAllData, settings, setSettings, theme } = useContext(CounterContext);
    const toggleDark = () => setSettings({ ...settings, darkMode: !settings.darkMode });
    const toggleNotify = () => setSettings({ ...settings, notifications: !settings.notifications });
    const handleClear = () => {
        Alert.alert("Clear Data", "Are you sure? This cannot be undone.", [
            { text: "Cancel", style: 'cancel' },
            { text: "Delete", style: 'destructive', onPress: clearAllData }
        ]);
    };
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
            <ScrollView contentContainerStyle={styles.scrollContent}>
                <View style={styles.header}>
                    <Text style={[styles.headerTitle, { color: theme.text }]}>Settings</Text>
                    <Text style={[styles.headerSubtitle, { color: theme.textSub }]}>Customize your experience</Text>
                </View>
                {/* Appearance */}
                <SettingSection title="APPEARANCE" theme={theme}>
                    <SettingRow theme={theme}>
                        <View style={[styles.settingIconBg, { backgroundColor: theme.iconBg }]}>
                            <Feather name="moon" size={20} color={theme.text} />
                        </View>
                        <View style={styles.settingTextContainer}>
                            <Text style={[styles.settingTitle, { color: theme.text }]}>Dark Mode</Text>
                            <Text style={[styles.settingSubtitle, { color: theme.textSub }]}>Switch to dark theme</Text>
                        </View>
                        <Switch
                            value={settings.darkMode}
                            onValueChange={toggleDark}
                            trackColor={{ true: theme.primaryStart }}
                            thumbColor={theme.white}
                        />
                    </SettingRow>
                </SettingSection>
                {/* Notifications */}
                <SettingSection title="NOTIFICATIONS" theme={theme}>
                    <SettingRow theme={theme}>
                        <View style={[styles.settingIconBg, { backgroundColor: theme.iconBg }]}>
                            <Feather name="bell" size={20} color={theme.text} />
                        </View>
                        <View style={styles.settingTextContainer}>
                            <Text style={[styles.settingTitle, { color: theme.text }]}>Daily Reminders</Text>
                            <Text style={[styles.settingSubtitle, { color: theme.textSub }]}>Get notified to count</Text>
                        </View>
                        <Switch
                            value={settings.notifications}
                            onValueChange={toggleNotify}
                            trackColor={{ true: theme.primaryStart }}
                            thumbColor={theme.white}
                        />
                    </SettingRow>
                </SettingSection>
                {/* Data */}
                <SettingSection title="DATA" theme={theme}>
                    <TouchableOpacity style={[styles.settingRowBase, { borderBottomWidth: 1, borderBottomColor: theme.border }]}>
                        <View style={[styles.settingIconBg, { backgroundColor: theme.iconBg }]}>
                            <Feather name="download" size={20} color={theme.text} />
                        </View>
                        <View style={styles.settingTextContainer}>
                            <Text style={[styles.settingTitle, { color: theme.text }]}>Export to CSV</Text>
                            <Text style={[styles.settingSubtitle, { color: theme.textSub }]}>Download your data</Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.settingRowBase} onPress={handleClear}>
                        <View style={[styles.settingIconBg, { backgroundColor: theme.dangerBg }]}>
                            <Feather name="trash-2" size={20} color={theme.dangerText} />
                        </View>
                        <View style={styles.settingTextContainer}>
                            <Text style={[styles.settingTitle, { color: theme.dangerText }]}>Clear All Data</Text>
                            <Text style={[styles.settingSubtitle, { color: theme.textSub }]}>Delete everything</Text>
                        </View>
                    </TouchableOpacity>
                </SettingSection>
            </ScrollView>
        </SafeAreaView>
    );
};
const SettingSection = ({ title, children, theme }) => (
    <View style={styles.settingSection}>
        <Text style={[styles.settingHeader, { color: theme.textSub }]}>{title}</Text>
        <View style={[styles.settingCard, { backgroundColor: theme.card }]}>
            {children}
        </View>
    </View>
);
const SettingRow = ({ children, theme }) => (
    <View style={styles.settingRowBase}>
        {children}
    </View>
);
// 4. COUNTER DETAIL SCREEN
const CounterDetailScreen = ({ route, navigation }) => {
    const { counterId } = route.params;
    const { counters, incrementCounter, resetCounter, theme } = useContext(CounterContext);
    const counter = counters.find(c => c.id === counterId);
    if (!counter) return null;
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
            <View style={styles.detailHeader}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Feather name="arrow-left" size={24} color={theme.text} />
                </TouchableOpacity>
                <Text style={[styles.detailTitle, { color: theme.text }]}>{counter.title}</Text>
                <TouchableOpacity onPress={() => navigation.navigate('Settings')}>
                    <Feather name="settings" size={24} color={theme.text} />
                </TouchableOpacity>
            </View>
            <View style={styles.counterDisplayContainer}>
                <Text style={[styles.bigCount, { color: counter.color }]}>{counter.count}</Text>
                <TouchableOpacity
                    style={[styles.tapButtonContainer, { shadowColor: counter.color }]}
                    activeOpacity={0.8}
                    onPress={() => incrementCounter(counter.id, 1)}
                >
                    <LinearGradient
                        colors={[counter.color, theme.primaryEnd]} // Use counter color
                        style={styles.tapButton}
                    >
                        <Text style={styles.tapText}>TAP</Text>
                    </LinearGradient>
                </TouchableOpacity>
            </View>
            <View style={styles.controlsRow}>
                <RoundControlBtn icon="minus" onPress={() => incrementCounter(counter.id, -1)} theme={theme} />
                <RoundControlBtn icon="refresh-ccw" onPress={() => resetCounter(counter.id)} theme={theme} />
                <TouchableOpacity style={[styles.controlBtn, { backgroundColor: theme.iconBg }]} onPress={() => incrementCounter(counter.id, 5)}>
                    <Text style={{ fontWeight: 'bold', fontSize: 18, color: theme.text }}>+5</Text>
                </TouchableOpacity>
            </View>
            <View style={{ alignItems: 'center', marginTop: 40 }}>
                <TouchableOpacity style={[styles.shareBtn, { backgroundColor: theme.iconBg }]}>
                    <Feather name="share-2" size={18} color={theme.text} />
                    <Text style={{ marginLeft: 8, fontWeight: '600', color: theme.text }}>Share</Text>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
};
const RoundControlBtn = ({ icon, onPress, theme }) => (
    <TouchableOpacity style={[styles.controlBtn, { backgroundColor: theme.iconBg }]} onPress={onPress}>
        <Feather name={icon} size={24} color={theme.text} />
    </TouchableOpacity>
);
// 5. NEW COUNTER SCREEN
const NewCounterScreen = ({ navigation }) => {
    const { addCounter, theme } = useContext(CounterContext);
    const [name, setName] = useState('');
    const [selectedColor, setSelectedColor] = useState(theme.primaryStart);
    const colors = [
        theme.primaryStart, '#EC4899', '#14B8A6', '#F59E0B', '#3B82F6', '#10B981'
    ];
    const handleCreate = () => {
        addCounter(name, selectedColor);
        navigation.goBack();
    };
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
            <View style={styles.detailHeader}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Feather name="arrow-left" size={24} color={theme.text} />
                </TouchableOpacity>
                <Text style={[styles.detailTitle, { color: theme.text }]}>New Counter</Text>
                <TouchableOpacity onPress={handleCreate}>
                    <LinearGradient
                        colors={[theme.primaryStart, theme.primaryEnd]}
                        style={styles.checkBtn}
                    >
                        <Feather name="check" size={20} color={theme.white} />
                    </LinearGradient>
                </TouchableOpacity>
            </View>
            <View style={styles.formContent}>
                <View style={styles.previewContainer}>
                    <LinearGradient
                        colors={[selectedColor, selectedColor]}
                        style={styles.previewBox}
                    >
                        <Text style={styles.previewText}>0</Text>
                    </LinearGradient>
                </View>
                <Text style={[styles.inputLabel, { color: theme.textSub }]}>Counter Name</Text>
                <TextInput
                    style={[styles.input, { backgroundColor: theme.inputBg, color: theme.text }]}
                    placeholder="e.g., Daily Steps..."
                    placeholderTextColor={theme.textSub}
                    value={name}
                    onChangeText={setName}
                />
                <Text style={[styles.inputLabel, { color: theme.textSub }]}>Choose Color</Text>
                <View style={styles.colorGrid}>
                    {colors.map(color => (
                        <TouchableOpacity
                            key={color}
                            onPress={() => setSelectedColor(color)}
                            style={[
                                styles.colorOption,
                                { backgroundColor: color },
                                selectedColor === color && styles.colorSelected
                            ]}
                        >
                            {selectedColor === color && <Feather name="check" size={24} color="white" />}
                        </TouchableOpacity>
                    ))}
                </View>
            </View>
        </SafeAreaView>
    );
}
// --- NAVIGATION & ROOT ---
const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();
const MainTabs = () => {
    const { theme } = useContext(CounterContext);
    return (
        <Tab.Navigator
            screenOptions={({ route }) => ({
                headerShown: false,
                tabBarShowLabel: true,
                tabBarActiveTintColor: theme.primaryStart,
                tabBarInactiveTintColor: theme.textSub,
                tabBarStyle: {
                    backgroundColor: theme.background,
                    borderTopColor: theme.border,
                    height: 60, paddingBottom: 10, paddingTop: 10
                },
                tabBarIcon: ({ color, size }) => {
                    let iconName;
                    if (route.name === 'Home') iconName = 'home';
                    else if (route.name === 'Stats') iconName = 'bar-chart-2';
                    else if (route.name === 'Settings') iconName = 'settings';
                    return <Feather name={iconName} size={24} color={color} />;
                }
            })}
        >
            <Tab.Screen name="Home" component={HomeScreen} />
            <Tab.Screen name="Stats" component={StatsScreen} />
            <Tab.Screen name="Settings" component={SettingsScreen} />
        </Tab.Navigator>
    );
};
const FAB = () => {
    const navigation = useNavigation();
    const { theme } = useContext(CounterContext);
    return (
        <TouchableOpacity
            style={styles.fab}
            onPress={() => navigation.navigate('NewCounter')}
        >
            <LinearGradient
                colors={[theme.primaryStart, theme.primaryEnd]}
                style={styles.fabGradient}
            >
                <Feather name="plus" size={32} color="white" />
            </LinearGradient>
        </TouchableOpacity>
    );
}
const MainWithFab = () => {
    return (
        <View style={{ flex: 1 }}>
            <MainTabs />
            <FAB />
        </View>
    )
}
export default function App() {
    return (
        <CounterProvider>
            <AppContent />
        </CounterProvider>
    );
}
const AppContent = () => {
    const { theme, isDark } = useContext(CounterContext);
    // Updates React Navigation Theme
    const NavTheme = {
        ...DefaultTheme,
        colors: {
            ...DefaultTheme.colors,
            background: theme.background,
            card: theme.card,
            text: theme.text,
        }
    };
    return (
        <NavigationContainer theme={NavTheme}>
            <StatusBar style={isDark ? "light" : "dark"} />
            <Stack.Navigator screenOptions={{ headerShown: false }}>
                <Stack.Screen name="Main" component={MainWithFab} />
                <Stack.Screen name="CounterDetail" component={CounterDetailScreen} />
                <Stack.Screen name="NewCounter" component={NewCounterScreen} presentation="modal" />
            </Stack.Navigator>
        </NavigationContainer>
    );
};
// --- STYLES ---
const styles = StyleSheet.create({
    container: { flex: 1 },
    scrollContent: { padding: 20, paddingBottom: 100 },
    // Header
    header: { flexDirection: 'row', alignItems: 'center', marginBottom: 24, marginTop: 10 },
    headerTitle: { fontSize: 24, fontWeight: 'bold' },
    headerSubtitle: { fontSize: 14 },
    iconBg: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#D946EF', justifyContent: 'center', alignItems: 'center', marginRight: 12 },
    // Dashboard
    dashboardCard: { borderRadius: 24, padding: 24, marginBottom: 32, shadowColor: '#D946EF', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.3, shadowRadius: 15, elevation: 10 },
    dashboardLabel: { color: 'rgba(255,255,255,0.8)', fontSize: 14, marginBottom: 4 },
    dashboardValue: { color: '#FFF', fontSize: 48, fontWeight: 'bold', marginBottom: 8 },
    dashboardFooter: { color: 'rgba(255,255,255,0.9)', fontSize: 14 },
    // Section
    sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 16 },
    sectionTitle: { fontSize: 18, fontWeight: 'bold' },
    sectionSubtitle: { fontSize: 14 },
    // Counters
    counterCard: { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 20, marginBottom: 12, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 5, elevation: 2 },
    counterIcon: { width: 50, height: 50, borderRadius: 16, justifyContent: 'center', alignItems: 'center', marginRight: 16 },
    counterIconText: { color: '#FFF', fontSize: 18, fontWeight: 'bold' },
    counterTitle: { fontSize: 16, fontWeight: '600', flex: 1 },
    // Stats
    statsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
    statBox: { width: '48%', borderRadius: 20, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 5, elevation: 2 },
    statIcon: { width: 32, height: 32, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
    statValue: { fontSize: 24, fontWeight: 'bold', marginBottom: 4 },
    statLabel: { fontSize: 12 },
    chartCard: { borderRadius: 24, padding: 20, marginBottom: 24 },
    chartTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 20 },
    chartContainer: { flexDirection: 'row', justifyContent: 'space-between', height: 200, alignItems: 'flex-end' },
    barContainer: { alignItems: 'center', width: 30 },
    barTrack: { width: 12, height: 150, borderRadius: 6, justifyContent: 'flex-end', overflow: 'hidden' },
    barFill: { width: '100%', borderRadius: 6 },
    barLabel: { marginTop: 8, fontSize: 10 },
    // Settings
    settingSection: { marginBottom: 24 },
    settingHeader: { fontSize: 12, fontWeight: 'bold', marginBottom: 8, marginLeft: 4 },
    settingCard: { borderRadius: 20, overflow: 'hidden' },
    settingRowBase: { flexDirection: 'row', alignItems: 'center', padding: 16 },
    settingIconBg: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 16 },
    settingTextContainer: { flex: 1 },
    settingTitle: { fontSize: 16, fontWeight: '600' },
    settingSubtitle: { fontSize: 13 },
    // New Counter / Forms
    formContent: { padding: 20 },
    previewContainer: { alignItems: 'center', marginBottom: 40, marginTop: 20 },
    previewBox: { width: 120, height: 120, borderRadius: 30, justifyContent: 'center', alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.2, shadowRadius: 10, elevation: 10 },
    previewText: { fontSize: 40, fontWeight: 'bold', color: '#FFF' },
    inputLabel: { fontSize: 14, marginBottom: 8 },
    input: { borderRadius: 16, padding: 16, fontSize: 16, marginBottom: 24 },
    colorGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
    colorOption: { width: '48%', height: 60, borderRadius: 16, marginBottom: 16, justifyContent: 'center', alignItems: 'center' },
    colorSelected: { borderWidth: 3, borderColor: 'rgba(255,255,255,0.5)' },
    checkBtn: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
    // Detail
    detailHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20 },
    detailTitle: { fontSize: 18, fontWeight: 'bold' },
    counterDisplayContainer: { alignItems: 'center', justifyContent: 'center', marginTop: 40, marginBottom: 60 },
    bigCount: { fontSize: 80, fontWeight: 'bold', marginBottom: 40 },
    tapButtonContainer: { shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.4, shadowRadius: 20, elevation: 15 },
    tapButton: { width: 200, height: 200, borderRadius: 100, justifyContent: 'center', alignItems: 'center' },
    tapText: { color: '#FFF', fontSize: 32, fontWeight: 'bold' },
    controlsRow: { flexDirection: 'row', justifyContent: 'center', gap: 20 },
    controlBtn: { width: 60, height: 60, borderRadius: 30, justifyContent: 'center', alignItems: 'center' },
    shareBtn: { paddingVertical: 12, paddingHorizontal: 24, borderRadius: 24, flexDirection: 'row', alignItems: 'center' },
    counterSubtitle: { fontSize: 13 },
    // FAB
    fab: { position: 'absolute', bottom: 85, alignSelf: 'center', shadowColor: '#D946EF', shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.3, shadowRadius: 10, elevation: 8 },
    fabGradient: { width: 64, height: 64, borderRadius: 32, justifyContent: 'center', alignItems: 'center' }
});